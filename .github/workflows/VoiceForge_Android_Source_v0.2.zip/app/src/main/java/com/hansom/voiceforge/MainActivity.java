package com.hansom.voiceforge;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO_PERMISSION = 501;
    private static final int REQ_DOC = 502;
    private static final int REQ_AUDIO_FILE = 503;
    private static final String PREFS = "voiceforge_prefs";
    private static final String KEY_ALIAS = "voiceforge_fish_api_key";
    private static final String FISH_MODEL_URL = "https://api.fish.audio/model";
    private static final String FISH_TTS_URL = "https://api.fish.audio/v1/tts";
    private static final String FISH_API_PAGE = "https://fish.audio/app/api-keys";
    private static final String FISH_MODEL_HEADER = "s2.1-pro-free";

    private WebView webView;
    private MediaRecorder recorder;
    private MediaPlayer player;
    private File lastSample;
    private long recordStart = 0;
    private SharedPreferences prefs;
    private final List<File> generatedPlaylist = new ArrayList<>();
    private int playlistIndex = 0;
    private final AtomicBoolean generating = new AtomicBoolean(false);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(11,11,12));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(11,11,12));
        PDFBoxResourceLoader.init(getApplicationContext());
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        restoreSample();
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setDefaultTextEncodingName("utf-8");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new Bridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void restoreSample() {
        String path = prefs == null ? "" : prefs.getString("voice_sample_path", "");
        if (!path.isEmpty()) {
            File f = new File(path);
            if (f.exists()) lastSample = f;
        }
    }

    private void js(String code) { runOnUiThread(() -> webView.evaluateJavascript(code, null)); }
    private void toast(String msg) { runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show()); }

    public class Bridge {
        @JavascriptInterface
        public String getState() {
            try {
                JSONObject o = new JSONObject();
                o.put("hasKey", !getApiKey().isEmpty());
                o.put("hasSample", lastSample != null && lastSample.exists());
                o.put("voiceId", prefs.getString("voice_id", ""));
                o.put("voiceState", prefs.getString("voice_state", ""));
                o.put("sampleName", prefs.getString("voice_sample_name", ""));
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }

        @JavascriptInterface
        public void saveApiKey(String key) {
            String clean = key == null ? "" : key.trim();
            if (clean.length() < 12) {
                js("window.onApiKeySaved&&window.onApiKeySaved(false,'API Key 格式看起来不正确')");
                return;
            }
            try {
                saveEncrypted("fish_api_key", clean);
                js("window.onApiKeySaved&&window.onApiKeySaved(true,'已用 Android Keystore 加密保存')");
            } catch (Exception e) {
                js("window.onApiKeySaved&&window.onApiKeySaved(false,'" + jse("保存失败：" + e.getMessage()) + "')");
            }
        }

        @JavascriptInterface public void clearApiKey() { prefs.edit().remove("fish_api_key_iv").remove("fish_api_key_ct").apply(); js("window.onApiKeyCleared&&window.onApiKeyCleared()"); }
        @JavascriptInterface public void openApiKeyPage() { openExternal(FISH_API_PAGE); }

        @JavascriptInterface
        public void startRecording() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO_PERMISSION);
                    return;
                }
                reallyStartRecording();
            });
        }

        @JavascriptInterface public void stopRecording() { runOnUiThread(() -> reallyStopRecording()); }

        @JavascriptInterface
        public void pickVoiceSample() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("audio/*");
                startActivityForResult(i, REQ_AUDIO_FILE);
            });
        }

        @JavascriptInterface
        public void playSample() {
            runOnUiThread(() -> {
                if (lastSample == null || !lastSample.exists()) { toast("还没有声音样本"); return; }
                playFile(lastSample);
            });
        }

        @JavascriptInterface
        public void createVoice(String displayName, String transcript, boolean consent) {
            if (!consent) { js("window.onCloneError&&window.onCloneError('必须确认声音所有权或已获得明确授权')"); return; }
            if (generating.get()) { js("window.onCloneError&&window.onCloneError('当前正在生成音频，请稍后再操作')"); return; }
            final String apiKey = getApiKey();
            if (apiKey.isEmpty()) { js("window.onCloneError&&window.onCloneError('请先在设置中填写 Fish Audio API Key')"); return; }
            if (lastSample == null || !lastSample.exists()) { js("window.onCloneError&&window.onCloneError('请先录制或导入声音样本')"); return; }
            final String name = (displayName == null || displayName.trim().isEmpty()) ? "我的声音" : displayName.trim();
            final String refText = transcript == null ? "" : transcript.trim();
            new Thread(() -> {
                try {
                    js("window.onCloneProgress&&window.onCloneProgress('正在上传参考声音…')");
                    JSONObject created = createFishVoice(apiKey, name, refText, lastSample);
                    String id = created.optString("_id", created.optString("id", ""));
                    String state = created.optString("state", "created");
                    if (id.isEmpty()) throw new IOException("服务端没有返回 Voice ID");
                    prefs.edit().putString("voice_id", id).putString("voice_state", state).putString("voice_name", name).apply();
                    js("window.onCloneCreated&&window.onCloneCreated('" + jse(id) + "','" + jse(state) + "')");
                    pollVoiceUntilReady(apiKey, id);
                } catch (Exception e) {
                    js("window.onCloneError&&window.onCloneError('" + jse(humanApiError(e)) + "')");
                }
            }).start();
        }

        @JavascriptInterface
        public void refreshVoice() {
            String id = prefs.getString("voice_id", ""); String apiKey = getApiKey();
            if (id.isEmpty() || apiKey.isEmpty()) return;
            new Thread(() -> {
                try {
                    JSONObject o = getFishVoice(apiKey, id);
                    String state = o.optString("state", "unknown");
                    prefs.edit().putString("voice_state", state).apply();
                    js("window.onVoiceState&&window.onVoiceState('" + jse(state) + "')");
                } catch (Exception e) { js("window.onCloneError&&window.onCloneError('" + jse(humanApiError(e)) + "')"); }
            }).start();
        }

        @JavascriptInterface
        public void deleteVoice() {
            final String id = prefs.getString("voice_id", ""); final String apiKey = getApiKey();
            new Thread(() -> {
                if (!id.isEmpty() && !apiKey.isEmpty()) { try { deleteFishVoice(apiKey, id); } catch (Exception ignored) {} }
                prefs.edit().remove("voice_id").remove("voice_state").remove("voice_name").apply();
                js("window.onVoiceDeleted&&window.onVoiceDeleted()");
            }).start();
        }

        @JavascriptInterface
        public void pickDocument() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"text/plain","text/markdown","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/pdf"});
                startActivityForResult(i, REQ_DOC);
            });
        }

        @JavascriptInterface
        public void synthesize(String text, String style, int intensity, double speed, int pause, int warmth, int power, boolean preview) {
            if (generating.get()) { js("window.onGenerationError&&window.onGenerationError('已有生成任务正在进行')"); return; }
            final String clean = text == null ? "" : text.trim();
            if (clean.isEmpty()) { js("window.onGenerationError&&window.onGenerationError('请先导入或粘贴文字')"); return; }
            final String apiKey = getApiKey(); final String voiceId = prefs.getString("voice_id", "");
            if (apiKey.isEmpty()) { js("window.onGenerationError&&window.onGenerationError('请先填写 Fish Audio API Key')"); return; }
            if (voiceId.isEmpty()) { js("window.onGenerationError&&window.onGenerationError('请先建立“我的音色”')"); return; }
            generating.set(true);
            new Thread(() -> {
                try {
                    generatedPlaylist.clear(); playlistIndex = 0;
                    String source = preview ? firstPreview(clean) : clean;
                    List<String> chunks = preview ? Collections.singletonList(source) : splitText(source, 850);
                    int total = chunks.size();
                    for (int i = 0; i < total; i++) {
                        int current = i + 1;
                        js("window.onGenerationProgress&&window.onGenerationProgress(" + current + "," + total + ",'正在生成第 " + current + " 段')");
                        String directed = directText(chunks.get(i), style, intensity, pause, warmth, power);
                        byte[] audio = requestTts(apiKey, voiceId, directed, speed, power);
                        File dir = new File(getFilesDir(), "generated"); if (!dir.exists()) dir.mkdirs();
                        File out = new File(dir, (preview ? "preview" : "full") + "_" + System.currentTimeMillis() + "_" + i + ".mp3");
                        try (FileOutputStream fos = new FileOutputStream(out)) { fos.write(audio); }
                        generatedPlaylist.add(out);
                    }
                    js("window.onGenerationComplete&&window.onGenerationComplete(" + generatedPlaylist.size() + "," + (preview ? "true" : "false") + ")");
                    runOnUiThread(() -> playPlaylistFromStart());
                } catch (Exception e) {
                    js("window.onGenerationError&&window.onGenerationError('" + jse(humanApiError(e)) + "')");
                } finally { generating.set(false); }
            }).start();
        }

        @JavascriptInterface public void replayGenerated() { runOnUiThread(() -> playPlaylistFromStart()); }
        @JavascriptInterface public void stopAudio() { runOnUiThread(() -> { if (player != null) { try { player.stop(); } catch (Exception ignored) {} player.release(); player = null; } }); }
    }

    private void reallyStartRecording() {
        try {
            if (recorder != null) return;
            File f = new File(getFilesDir(), "voice_reference.m4a"); if (f.exists()) f.delete(); lastSample = f;
            recorder = new MediaRecorder(); recorder.setAudioSource(MediaRecorder.AudioSource.MIC); recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); recorder.setAudioEncodingBitRate(160000); recorder.setAudioSamplingRate(44100);
            recorder.setOutputFile(lastSample.getAbsolutePath()); recorder.prepare(); recorder.start(); recordStart = System.currentTimeMillis();
            js("window.onRecordingStarted&&window.onRecordingStarted()");
        } catch (Exception e) { recorder = null; toast("录音启动失败：" + e.getMessage()); }
    }

    private void reallyStopRecording() {
        if (recorder == null) return;
        try {
            recorder.stop(); long ms = Math.max(0, System.currentTimeMillis() - recordStart); recorder.release(); recorder = null;
            prefs.edit().putString("voice_sample_path", lastSample.getAbsolutePath()).putString("voice_sample_name", "voice_reference.m4a").apply();
            js("window.onRecordingStopped&&window.onRecordingStopped(" + ms + ")");
        } catch (Exception e) {
            try { recorder.release(); } catch (Exception ignored) {} recorder = null; if (lastSample != null) lastSample.delete();
            js("window.onRecordingError&&window.onRecordingError('录音太短或保存失败，请重新录制')");
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO_PERMISSION && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) reallyStartRecording();
        else if (requestCode == REQ_AUDIO_PERMISSION) toast("需要麦克风权限才能录制声音样本");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_AUDIO_FILE) { new Thread(() -> importAudioSample(uri)).start(); return; }
        if (requestCode == REQ_DOC) {
            new Thread(() -> {
                try {
                    String name = getFileName(uri); String lower = name.toLowerCase(Locale.ROOT); String text;
                    if (lower.endsWith(".docx")) text = extractDocx(uri); else if (lower.endsWith(".pdf")) text = extractPdf(uri); else text = readText(uri);
                    js("window.onDocumentImported&&window.onDocumentImported('" + jse(name) + "','" + jse(text) + "')");
                } catch (Exception e) { js("window.onImportError&&window.onImportError('" + jse("文档读取失败：" + e.getMessage()) + "')"); }
            }).start();
        }
    }

    private void importAudioSample(Uri uri) {
        try {
            String name = getFileName(uri); String ext = "m4a"; int dot = name.lastIndexOf('.');
            if (dot >= 0 && dot < name.length() - 1) { String e = name.substring(dot + 1).toLowerCase(Locale.ROOT); if (Arrays.asList("m4a","mp3","wav","aac","flac","ogg","opus","webm").contains(e)) ext = e; }
            File dst = new File(getFilesDir(), "voice_reference." + ext);
            try (InputStream in = getContentResolver().openInputStream(uri); FileOutputStream out = new FileOutputStream(dst)) {
                if (in == null) throw new IOException("无法读取声音文件"); byte[] buf = new byte[8192]; int n; long total = 0;
                while ((n = in.read(buf)) != -1) { total += n; if (total > 10L * 1024L * 1024L) throw new IOException("声音文件超过 10MB"); out.write(buf, 0, n); }
            }
            lastSample = dst; prefs.edit().putString("voice_sample_path", dst.getAbsolutePath()).putString("voice_sample_name", name).apply();
            js("window.onVoiceSampleImported&&window.onVoiceSampleImported('" + jse(name) + "')");
        } catch (Exception e) { js("window.onRecordingError&&window.onRecordingError('" + jse("声音样本导入失败：" + e.getMessage()) + "')"); }
    }

    private JSONObject createFishVoice(String apiKey, String name, String transcript, File audio) throws Exception {
        String boundary = "----VoiceForge" + System.currentTimeMillis();
        HttpURLConnection conn = (HttpURLConnection) new URL(FISH_MODEL_URL).openConnection();
        conn.setConnectTimeout(30000); conn.setReadTimeout(120000); conn.setDoOutput(true); conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey); conn.setRequestProperty("Accept", "application/json"); conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        try (DataOutputStream out = new DataOutputStream(conn.getOutputStream())) {
            writeField(out, boundary, "title", name); writeField(out, boundary, "description", "VoiceForge 私有声音模型"); writeField(out, boundary, "visibility", "private");
            writeField(out, boundary, "type", "tts"); writeField(out, boundary, "train_mode", "fast"); writeField(out, boundary, "enhance_audio_quality", "true");
            if (transcript != null && !transcript.isEmpty()) writeField(out, boundary, "texts", transcript);
            out.writeBytes("--" + boundary + "\r\n"); out.writeBytes("Content-Disposition: form-data; name=\"voices\"; filename=\"" + safeAsciiFileName(audio.getName()) + "\"\r\n");
            out.writeBytes("Content-Type: " + mimeFor(audio.getName()) + "\r\n\r\n");
            try (FileInputStream in = new FileInputStream(audio)) { byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) != -1) out.write(buf, 0, n); }
            out.writeBytes("\r\n--" + boundary + "--\r\n"); out.flush();
        }
        int code = conn.getResponseCode(); String body = readResponse(conn, code); conn.disconnect();
        if (code < 200 || code >= 300) throw new IOException("Fish Audio " + code + ": " + body); return new JSONObject(body);
    }

    private JSONObject getFishVoice(String apiKey, String id) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(FISH_MODEL_URL + "/" + id).openConnection();
        conn.setConnectTimeout(20000); conn.setReadTimeout(30000); conn.setRequestMethod("GET"); conn.setRequestProperty("Authorization", "Bearer " + apiKey); conn.setRequestProperty("Accept", "application/json");
        int code = conn.getResponseCode(); String body = readResponse(conn, code); conn.disconnect(); if (code < 200 || code >= 300) throw new IOException("Fish Audio " + code + ": " + body); return new JSONObject(body);
    }

    private void deleteFishVoice(String apiKey, String id) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(FISH_MODEL_URL + "/" + id).openConnection();
        conn.setConnectTimeout(20000); conn.setReadTimeout(30000); conn.setRequestMethod("DELETE"); conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        int code = conn.getResponseCode(); if (code < 200 || code >= 300) { String body = readResponse(conn, code); conn.disconnect(); throw new IOException("Fish Audio " + code + ": " + body); } conn.disconnect();
    }

    private void pollVoiceUntilReady(String apiKey, String id) {
        for (int i = 0; i < 18; i++) {
            try {
                JSONObject o = getFishVoice(apiKey, id); String state = o.optString("state", "unknown"); prefs.edit().putString("voice_state", state).apply(); js("window.onVoiceState&&window.onVoiceState('" + jse(state) + "')");
                if ("trained".equalsIgnoreCase(state) || "ready".equalsIgnoreCase(state) || "failed".equalsIgnoreCase(state)) return;
                Thread.sleep(3000);
            } catch (Exception e) { return; }
        }
    }

    private byte[] requestTts(String apiKey, String voiceId, String text, double speed, int power) throws Exception {
        JSONObject body = new JSONObject(); body.put("text", text); body.put("reference_id", voiceId); body.put("format", "mp3"); body.put("mp3_bitrate", 128); body.put("normalize", true); body.put("temperature", 0.72); body.put("top_p", 0.72);
        JSONObject prosody = new JSONObject(); prosody.put("speed", Math.max(0.65, Math.min(1.35, speed))); double volume = (power - 50) / 5.0; prosody.put("volume", Math.max(-8.0, Math.min(8.0, volume))); body.put("prosody", prosody);
        byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
        HttpURLConnection conn = (HttpURLConnection) new URL(FISH_TTS_URL).openConnection(); conn.setConnectTimeout(30000); conn.setReadTimeout(180000); conn.setDoOutput(true); conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey); conn.setRequestProperty("Content-Type", "application/json"); conn.setRequestProperty("Accept", "audio/mpeg"); conn.setRequestProperty("model", FISH_MODEL_HEADER); conn.setFixedLengthStreamingMode(payload.length);
        try (OutputStream out = conn.getOutputStream()) { out.write(payload); }
        int code = conn.getResponseCode(); if (code < 200 || code >= 300) { String err = readResponse(conn, code); conn.disconnect(); throw new IOException("Fish Audio " + code + ": " + err); }
        try (InputStream in = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) { byte[] buf = new byte[16384]; int n; while ((n = in.read(buf)) != -1) out.write(buf, 0, n); conn.disconnect(); return out.toByteArray(); }
    }

    private String directText(String text, String style, int intensity, int pause, int warmth, int power) {
        String level = intensity >= 80 ? "强烈" : intensity >= 55 ? "明显" : intensity >= 30 ? "轻微" : "非常轻微"; String direction;
        switch (style == null ? "" : style) {
            case "机智勇敢": direction = "[" + level + "地自信、果断、机智，节奏明快，咬字清楚，带一点锋利和幽默]"; break;
            case "深情慈悲": direction = "[" + level + "地温暖、共情、从容、悲悯，有呼吸感，不煽情]"; break;
            case "嚣张跋扈": direction = "[" + level + "地强势、傲慢、自信、带压迫感和挑衅感，句尾有控制力]"; break;
            case "风流倜傥": direction = "[" + level + "地松弛、自信、潇洒、迷人，略带漫不经心和玩味]"; break;
            case "雄浑壮烈": direction = "[" + level + "地雄浑、厚重、庄严、史诗感强，力量逐步推进，关键句有爆发力]"; break;
            default: direction = "[" + level + "地低沉、稳重、克制，情绪压在字后面，少炫技，句尾收住]";
        }
        String extra = ""; if (warmth >= 70) extra += "[声音更温暖] "; else if (warmth <= 30) extra += "[声音更冷静] "; if (power >= 80) extra += "[更有力量，但不要失真] "; else if (power <= 30) extra += "[更轻、更收敛] ";
        String t = text; if (pause >= 75) t = t.replace("。", "。[slight pause] ").replace("！", "！[slight pause] ").replace("\n\n", "\n[long pause]\n"); else if (pause >= 45) t = t.replace("\n\n", "\n[slight pause]\n");
        return direction + " " + extra + t;
    }

    private List<String> splitText(String text, int maxChars) {
        List<String> out = new ArrayList<>(); String normalized = text.replace("\r", "").trim(); if (normalized.length() <= maxChars) { out.add(normalized); return out; }
        String[] paras = normalized.split("\n+"); StringBuilder current = new StringBuilder();
        for (String para : paras) {
            String p = para.trim(); if (p.isEmpty()) continue;
            if (p.length() > maxChars) {
                for (String s : splitSentences(p)) {
                    if (current.length() + s.length() + 1 > maxChars && current.length() > 0) { out.add(current.toString().trim()); current.setLength(0); }
                    if (s.length() > maxChars) { int pos = 0; while (pos < s.length()) { int end = Math.min(pos + maxChars, s.length()); if (current.length() > 0) { out.add(current.toString().trim()); current.setLength(0); } out.add(s.substring(pos, end).trim()); pos = end; } }
                    else current.append(s);
                }
            } else { if (current.length() + p.length() + 2 > maxChars && current.length() > 0) { out.add(current.toString().trim()); current.setLength(0); } current.append(p).append("\n"); }
        }
        if (current.length() > 0) out.add(current.toString().trim()); return out;
    }

    private List<String> splitSentences(String text) { List<String> list = new ArrayList<>(); StringBuilder b = new StringBuilder(); for (int i=0;i<text.length();i++){char c=text.charAt(i);b.append(c);if("。！？!?；;".indexOf(c)>=0){list.add(b.toString());b.setLength(0);}} if(b.length()>0)list.add(b.toString()); return list; }
    private String firstPreview(String text) { int max=Math.min(150,text.length()),end=max; for(int i=Math.min(text.length()-1,150);i>=60;i--){if("。！？!?；;".indexOf(text.charAt(i))>=0){end=i+1;break;}} return text.substring(0,end); }

    private void playPlaylistFromStart() { if (generatedPlaylist.isEmpty()) return; playlistIndex = 0; playNextInPlaylist(); }
    private void playNextInPlaylist() {
        if (playlistIndex >= generatedPlaylist.size()) { js("window.onPlaybackFinished&&window.onPlaybackFinished()"); return; }
        File f = generatedPlaylist.get(playlistIndex++);
        try { if (player != null) player.release(); player = new MediaPlayer(); player.setDataSource(f.getAbsolutePath()); player.setOnCompletionListener(mp -> playNextInPlaylist()); player.prepare(); player.start(); js("window.onPlaybackStarted&&window.onPlaybackStarted(" + playlistIndex + "," + generatedPlaylist.size() + ")"); }
        catch (Exception e) { toast("播放失败：" + e.getMessage()); }
    }
    private void playFile(File file) { try { if(player!=null)player.release(); player=new MediaPlayer(); player.setDataSource(file.getAbsolutePath()); player.prepare(); player.start(); } catch(Exception e){ toast("播放失败："+e.getMessage()); } }

    private String getFileName(Uri uri) { String result="文件"; Cursor c=getContentResolver().query(uri,null,null,null,null); if(c!=null){int idx=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(idx>=0&&c.moveToFirst())result=c.getString(idx);c.close();} return result==null?"文件":result; }
    private String readText(Uri uri) throws Exception { try(InputStream in=getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){if(in==null)throw new IOException("无法打开文件");byte[]buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);return out.toString(StandardCharsets.UTF_8.name());} }
    private String extractDocx(Uri uri) throws Exception { InputStream in=getContentResolver().openInputStream(uri);if(in==null)throw new IOException("无法打开DOCX");ZipInputStream zis=new ZipInputStream(in);ZipEntry entry;String xml=null;while((entry=zis.getNextEntry())!=null){if("word/document.xml".equals(entry.getName())){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[]buf=new byte[8192];int n;while((n=zis.read(buf))!=-1)out.write(buf,0,n);xml=out.toString(StandardCharsets.UTF_8.name());break;}}zis.close();if(xml==null)throw new IOException("DOCX正文不存在");xml=xml.replace("</w:p>","\n").replace("</w:tr>","\n").replace("</w:tc>","\t");return xml.replaceAll("<[^>]+>","").replace("&amp;","&").replace("&lt;","<").replace("&gt;",">").replace("&quot;","\"").replace("&#39;","'").replaceAll("\n{3,}","\n\n").trim(); }
    private String extractPdf(Uri uri) throws Exception { InputStream in=getContentResolver().openInputStream(uri);if(in==null)throw new IOException("无法打开PDF");PDDocument doc=PDDocument.load(in);String text=new PDFTextStripper().getText(doc);doc.close();in.close();return text==null?"":text.trim(); }

    private void writeField(DataOutputStream out,String boundary,String name,String value)throws IOException{out.writeBytes("--"+boundary+"\r\n");out.writeBytes("Content-Disposition: form-data; name=\""+name+"\"\r\n");out.writeBytes("Content-Type: text/plain; charset=UTF-8\r\n\r\n");out.write(value.getBytes(StandardCharsets.UTF_8));out.writeBytes("\r\n");}
    private String readResponse(HttpURLConnection conn,int code)throws IOException{InputStream in=code>=400?conn.getErrorStream():conn.getInputStream();if(in==null)return"";try(InputStream input=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[]buf=new byte[8192];int n;while((n=input.read(buf))!=-1)out.write(buf,0,n);return out.toString(StandardCharsets.UTF_8.name());}}
    private String mimeFor(String name){String n=name.toLowerCase(Locale.ROOT);if(n.endsWith(".mp3"))return"audio/mpeg";if(n.endsWith(".wav"))return"audio/wav";if(n.endsWith(".aac"))return"audio/aac";if(n.endsWith(".ogg"))return"audio/ogg";if(n.endsWith(".webm"))return"audio/webm";if(n.endsWith(".flac"))return"audio/flac";return"audio/mp4";}
    private String safeAsciiFileName(String name){String ext=".m4a";int dot=name.lastIndexOf('.');if(dot>=0)ext=name.substring(dot);return"voice_reference"+ext.replaceAll("[^A-Za-z0-9.]","");}
    private void openExternal(String url){runOnUiThread(()->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){toast("无法打开浏览器");}});}

    private void saveEncrypted(String key,String value)throws Exception{SecretKey secretKey=getOrCreateSecretKey();Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,secretKey);byte[]iv=cipher.getIV();byte[]ct=cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));prefs.edit().putString(key+"_iv",Base64.encodeToString(iv,Base64.NO_WRAP)).putString(key+"_ct",Base64.encodeToString(ct,Base64.NO_WRAP)).apply();}
    private String getApiKey(){try{String iv64=prefs.getString("fish_api_key_iv","");String ct64=prefs.getString("fish_api_key_ct","");if(iv64.isEmpty()||ct64.isEmpty())return"";SecretKey secretKey=getOrCreateSecretKey();Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");GCMParameterSpec spec=new GCMParameterSpec(128,Base64.decode(iv64,Base64.NO_WRAP));cipher.init(Cipher.DECRYPT_MODE,secretKey,spec);byte[]pt=cipher.doFinal(Base64.decode(ct64,Base64.NO_WRAP));return new String(pt,StandardCharsets.UTF_8);}catch(Exception e){return"";}}
    private SecretKey getOrCreateSecretKey()throws Exception{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(ks.containsAlias(KEY_ALIAS)){KeyStore.SecretKeyEntry entry=(KeyStore.SecretKeyEntry)ks.getEntry(KEY_ALIAS,null);return entry.getSecretKey();}KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");KeyGenParameterSpec spec=new KeyGenParameterSpec.Builder(KEY_ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build();kg.init(spec);return kg.generateKey();}
    private String humanApiError(Exception e){String m=e.getMessage()==null?e.toString():e.getMessage();if(m.contains("401")||m.contains("403"))return"API Key 无效、权限不足或当前账户不可用。请检查 Fish Audio API Key。";if(m.contains("429"))return"Fish Audio 当前额度或频率受限，请检查账户额度后再试。";if(m.contains("413")||m.toLowerCase(Locale.ROOT).contains("too large"))return"声音样本或文本过大，请缩短后重试。";return m.length()>500?m.substring(0,500):m;}
    private String jse(String s){if(s==null)return"";return s.replace("\\","\\\\").replace("'","\\'").replace("\"","\\\"").replace("\r","").replace("\n","\\n").replace("\t","\\t").replace("</","<\\/");}

    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(recorder!=null){try{recorder.release();}catch(Exception ignored){}recorder=null;}if(player!=null){try{player.release();}catch(Exception ignored){}player=null;}if(webView!=null)webView.destroy();super.onDestroy();}
}
