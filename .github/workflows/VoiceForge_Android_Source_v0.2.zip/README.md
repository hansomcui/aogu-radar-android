# 声魄 VoiceForge Android v0.2

真正使用用户自己的音色朗读，而不是 Android 系统 TTS。

已实现：录制/导入参考声音、Android Keystore 加密保存 Fish Audio API Key、创建私有持久化 Voice ID、用同一 Voice ID 做六种演绎、DOCX/PDF/TXT/MD 导入、长文本分段生成和连续播放。

首次使用：在设置页获取并保存 Fish Audio API Key；录制 30–90 秒自然声音并确认授权；点击“建立我的音色”；得到 Voice ID 后导入文档，在导演台生成。
